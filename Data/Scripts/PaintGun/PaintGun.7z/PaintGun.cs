﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Engine.Physics;
using Sandbox.Engine.Multiplayer;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Interfaces;
using VRage.Common.Utils;
using VRageMath;
using VRage;
using VRage.ObjectBuilders;
using VRage.Components;
using VRage.ModAPI;
using VRage.Utils;
using Digi.Utils;

namespace Digi.PaintGun
{
    [MySessionComponentDescriptor(MyUpdateOrder.AfterSimulation)]
    public class PaintGun : MySessionComponentBase
    {
        public static bool init { get; private set; }
        public static bool isServer { get; private set; }
        public static bool isDedicated { get; private set; }
        
        private bool holdingTool = false;
        private bool pickColor = false;
        private Vector3 color = DEFAULT_COLOR;
        private IMyHudNotification toolStatus;
        private int skipUpdates;
        private long lastShotTime = 0;
        
        public const string MOD_NAME = "PaintGun";
        public const string PAINT_GUN_ID = "PaintGun";
        public const string PAINT_MAG_ID = "PaintGunMag";
        public const float PAINT_SPEED = 0.25f;
        public const float DEPAINT_SPEED = 0.33f;
        public const int SKIP_UPDATES = 10;
        public static Vector3 DEFAULT_COLOR = new Vector3(0, -1, 0);
        private static MyObjectBuilder_AmmoMagazine PAINT_MAG = new MyObjectBuilder_AmmoMagazine() { SubtypeName = PAINT_MAG_ID, ProjectilesCount = 1 };
        
        public Vector3[] defaultColors = new Vector3[14];
        
        public void Init()
        {
            init = true;
            isServer = MyAPIGateway.Session.OnlineMode == MyOnlineModeEnum.OFFLINE || MyAPIGateway.Multiplayer.IsServer;
            isDedicated = (MyAPIGateway.Utilities.IsDedicated && isServer);
            
            if(isDedicated)
                return;
            
            MyAPIGateway.Utilities.MessageEntered += MessageEntered;
            
            // snatched from MyPlayer.InitDefaultColors()
            defaultColors[0] = MyRenderComponentBase.OldGrayToHSV;
            defaultColors[1] = MyRenderComponentBase.OldRedToHSV;
            defaultColors[2] = MyRenderComponentBase.OldGreenToHSV;
            defaultColors[3] = MyRenderComponentBase.OldBlueToHSV;
            defaultColors[4] = MyRenderComponentBase.OldYellowToHSV;
            defaultColors[5] = MyRenderComponentBase.OldWhiteToHSV;
            defaultColors[6] = MyRenderComponentBase.OldBlackToHSV;
            
            for (int i = 7; i < defaultColors.Length; ++i)
            {
                defaultColors[i] = (defaultColors[i - 7] + new Vector3(0, 0.15f, 0.2f));
            }
        }
        
        protected override void UnloadData()
        {
            init = false;
            
            MyAPIGateway.Utilities.MessageEntered -= MessageEntered;
        }
        
        public override void UpdateAfterSimulation()
        {
            if(!init)
            {
                if(MyAPIGateway.Session == null)
                    return;
                
                Init();
            }
            
            if(!isDedicated && MyAPIGateway.Session.Player != null && MyAPIGateway.Session.Player.Controller != null && MyAPIGateway.Session.Player.Controller.ControlledEntity != null && MyAPIGateway.Session.Player.Controller.ControlledEntity.Entity != null)
            {
                var player = MyAPIGateway.Session.Player.Controller.ControlledEntity.Entity;
                
                if(player is IMyCharacter)
                {
                    var character = player.GetObjectBuilder(false) as MyObjectBuilder_Character;
                    var tool = character.HandWeapon as MyObjectBuilder_AutomaticRifle;
                    
                    if(tool != null && tool.SubtypeName == PAINT_GUN_ID)
                    {
                        if(!holdingTool)
                        {
                            DrawTool();
                            lastShotTime = tool.GunBase.LastShootTime;
                        }
                        
                        if(++skipUpdates >= SKIP_UPDATES)
                        {
                            skipUpdates = 0;
                            bool trigger = tool.GunBase.LastShootTime + (TimeSpan.TicksPerMillisecond * 200) > DateTime.UtcNow.Ticks;
                            bool painted = HoldingTool(trigger);
                            
                            // expend the ammo manually when painting
                            if(painted && !MyAPIGateway.Session.CreativeMode)
                            {
                                var inv = ((IMyInventoryOwner)player).GetInventory(0) as Sandbox.ModAPI.IMyInventory;
                                inv.RemoveItemsOfType((MyFixedPoint)1, PAINT_MAG, false);
                            }
                        }
                        
                        // always add the shot ammo back
                        if(tool.GunBase.LastShootTime > lastShotTime)
                        {
                            lastShotTime = tool.GunBase.LastShootTime;
                            
                            if(!MyAPIGateway.Session.CreativeMode)
                            {
                                var inv = ((IMyInventoryOwner)player).GetInventory(0) as Sandbox.ModAPI.IMyInventory;
                                inv.AddItems((MyFixedPoint)1, PAINT_MAG);
                            }
                        }
                        
                        return;
                    }
                }
            }
            
            if(holdingTool)
            {
                HolsterTool();
            }
        }
        
        private void RoundVector(ref Vector3 vec, int digits)
        {
            vec.X = (float)Math.Round(vec.X, digits);
            vec.Y = (float)Math.Round(vec.Y, digits);
            vec.Z = (float)Math.Round(vec.Z, digits);
        }
        
        private float Truncate(float value, int digits)
        {
            double mult = Math.Pow(10.0, digits);
            double result = Math.Truncate( mult * value ) / mult;
            return (float)result;
        }
        
        private void TruncateVector(ref Vector3 vec)
        {
            vec.X = Truncate(vec.X, 2);
            vec.Y = Truncate(vec.Y, 2);
            vec.Z = Truncate(vec.Z, 2);
        }
        
        public void SetColor(Vector3 color)
        {
            this.color = color;
        }
        
        private const int TOOLSTATUS_TIMEOUT = 200;
        
        private void SetToolStatus(string msg, MyFontEnum font, int aliveTime = TOOLSTATUS_TIMEOUT)
        {
            toolStatus.Font = font;
            toolStatus.Text = msg;
            toolStatus.AliveTime = aliveTime;
            toolStatus.Show();
        }
        
        private string ColorToString(Vector3 hsv)
        {
            return "Hue: " + (color.X * 360) + "*, saturation: " + (color.Y * 100) + ", value: " + (color.Z * 100);
        }
        
        private bool NearEqual(float val1, float val2, float epsilon = 0.01f)
        {
            return Math.Abs(val1 - val2) < epsilon;
        }
        
        private bool NearEqual(Vector3 val1, Vector3 val2, float epsilon = 0.01f)
        {
            return (NearEqual(val1.X, val2.X, epsilon) && NearEqual(val1.Y, val2.Y, epsilon) && NearEqual(val1.Z, val2.Z, epsilon));
        }
        
        public void DrawTool()
        {
            holdingTool = true;
            
            if(toolStatus == null)
            {
                toolStatus = MyAPIGateway.Utilities.CreateNotification("", 0, MyFontEnum.White);
                toolStatus.Hide();
            }
            
            SetToolStatus("Type /pg for Paint Gun options.", MyFontEnum.DarkBlue, 3000);
        }
        
        public bool HoldingTool(bool trigger)
        {
            try
            {
                var player = MyAPIGateway.Session.Player.Controller.ControlledEntity.Entity;
                var grid = MyAPIGateway.CubeBuilder.FindClosestGrid();
                
                if(grid == null)
                {
                    if(pickColor)
                    {
                        SetToolStatus("COLOR PICK MODE:\nNo ship target!", MyFontEnum.Red);
                    }
                    else if(trigger)
                    {
                        SetToolStatus("No ship target for painting.", MyFontEnum.Red);
                    }
                }
                else
                {
                    var view = MyAPIGateway.Session.ControlledObject.GetHeadMatrix(true, true);
                    var target = player.WorldAABB.Center + (view.Forward * (grid.GridSizeEnum == MyCubeSize.Small ? 1.5 : 1.5)) + (view.Up * 0.6);
                    var pos = grid.WorldToGridInteger(target);
                    var block = grid.GetCubeBlock(pos);
                    string blockName = null;
                    
                    if(block != null)
                    {
                        if(block.FatBlock == null)
                        {
                            blockName = block.ToString();
                        }
                        else
                        {
                            blockName = block.FatBlock.DefinitionDisplayNameText;
                        }
                        
                        if(pickColor)
                        {
                            if(trigger)
                            {
                                pickColor = false;
                                SetColor(block.GetColorMask());
                                SetToolStatus("COLOR PICK MODE:\nColor picked from " + blockName + ".", MyFontEnum.Green);
                            }
                            else
                            {
                                SetToolStatus("COLOR PICK MODE:\n" + blockName + "'s color is "+ColorToString(block.GetColorMask())+"\nClick to pick this color.", MyFontEnum.Blue);
                            }
                            
                            return false;
                        }
                        
                        if(block.HasDeformation || block.CurrentDamage > 0 || (block.FatBlock != null && !block.FatBlock.IsFunctional))
                        {
                            SetToolStatus("Paint target: " + blockName + "\n" + (block.HasDeformation || block.CurrentDamage > 0 ? "Block is damaged or deformed and can't be painted!" : "Block is not fully built and can't be painted!"), MyFontEnum.Red);
                            return false;
                        }
                        
                        if(!trigger)
                        {
                            SetToolStatus("Paint target: " + blockName, MyFontEnum.DarkBlue);
                        }
                    }
                    else
                    {
                        if(pickColor)
                        {
                            SetToolStatus("COLOR PICK MODE:\nNo block target!", MyFontEnum.Red);
                        }
                        else if(trigger)
                        {
                            SetToolStatus("No block target for painting.", MyFontEnum.Red);
                        }
                        
                        return false;
                    }
                    
                    if(trigger && block != null)
                    {
                        var blockColor = block.GetColorMask();
                        
                        if(NearEqual(blockColor, color, 0.001f))
                        {
                            SetToolStatus(blockName + " is painted your selected color.", MyFontEnum.Green);
                            return false;
                        }
                        
                        Vector3 blockSize;
                        block.ComputeScaledHalfExtents(out blockSize);
                        blockSize *= 2;
                        
                        float paintSpeed = (float)(1 / Math.Max(blockSize.Volume * 0.05, 1));
                        
                        // TODO REMOVE
                        //MyAPIGateway.Utilities.ShowNotification("blockColor="+blockColor.X+"; color="+color.X+", near="+NearEqual(blockColor.X, color.X), 160, MyFontEnum.Red);
                        
                        if(NearEqual(blockColor.X, color.X, 0.1f))
                        {
                            paintSpeed *= PAINT_SPEED;
                            paintSpeed *= MyAPIGateway.Session.WelderSpeedMultiplier;
                            
                            if(blockColor.Y > color.Y)
                                blockColor.Y = Math.Max(blockColor.Y - paintSpeed, color.Y);
                            else
                                blockColor.Y = Math.Min(blockColor.Y + paintSpeed, color.Y);
                            
                            if(blockColor.Z > color.Z)
                                blockColor.Z = Math.Max(blockColor.Z - paintSpeed, color.Z);
                            else
                                blockColor.Z = Math.Min(blockColor.Z + paintSpeed, color.Z);
                            
                            if(NearEqual(blockColor, color))
                            {
                                blockColor = color;
                                
                                SetToolStatus("Painting " + blockName + "... 100% done!", MyFontEnum.Blue);
                            }
                            else
                            {
                                float diff = (Math.Abs(blockColor.Y - color.Y) + Math.Abs(blockColor.Z - color.Z)) / 4;
                                float percent = 100 - (float)Math.Round(diff * 100, 0);
                                
                                SetToolStatus("Painting " + blockName + "... " + percent + "%", MyFontEnum.Blue);
                            }
                        }
                        else
                        {
                            paintSpeed *= DEPAINT_SPEED;
                            paintSpeed *= MyAPIGateway.Session.GrinderSpeedMultiplier;
                            
                            blockColor.Y = Math.Max(blockColor.Y - paintSpeed, DEFAULT_COLOR.Y);
                            
                            if(blockColor.Z > 0)
                                blockColor.Z = Math.Max(blockColor.Z - paintSpeed, DEFAULT_COLOR.Z);
                            else
                                blockColor.Z = Math.Min(blockColor.Z + paintSpeed, DEFAULT_COLOR.Z);
                            
                            if(NearEqual(blockColor.Y, DEFAULT_COLOR.Y) && NearEqual(blockColor.Z, DEFAULT_COLOR.Z))
                            {
                                blockColor.X = color.X;
                            }
                            
                            if(NearEqual(blockColor, DEFAULT_COLOR))
                            {
                                blockColor = DEFAULT_COLOR;
                                
                                if(color != DEFAULT_COLOR)
                                    SetToolStatus("Removing paint from " + blockName + "... 100%", MyFontEnum.Blue);
                                else
                                    SetToolStatus("Removing paint from " + blockName + "... 100% done!", MyFontEnum.Blue);
                            }
                            else
                            {
                                float diff = (Math.Abs(blockColor.Y - DEFAULT_COLOR.Y) + Math.Abs(blockColor.Z - DEFAULT_COLOR.Z)) / 4;
                                float percent = 100 - (float)Math.Round(diff * 100, 0);
                                
                                SetToolStatus("Removing paint from " + blockName + "... " + percent + "%", MyFontEnum.Blue);
                            }
                        }
                        
                        grid.ColorBlocks(pos, pos, blockColor);
                        return true;
                    }
                }
            }
            catch(Exception e)
            {
                Log.Error(e);
            }
            
            return false;
        }
        
        public void HolsterTool()
        {
            holdingTool = false;
        }
        
        public void MessageEntered(string msg, ref bool send)
        {
            if(msg.StartsWith("/pg", StringComparison.InvariantCultureIgnoreCase))
            {
                send = false;
                msg = msg.Substring("/pg".Length).Trim().ToLower();
                
                if(msg.Equals("pick"))
                {
                    if(!holdingTool)
                    {
                        MyAPIGateway.Utilities.ShowMessage(MOD_NAME, "You need to hold the tool for this to work.");
                    }
                    else
                    {
                        pickColor = true;
                    }
                    
                    return;
                }
                else if(msg.StartsWith("default"))
                {
                    msg = msg.Substring("default".Length).Trim();
                    
                    int num;
                    
                    if(!int.TryParse(msg, out num))
                    {
                        MyAPIGateway.Utilities.ShowMessage(MOD_NAME, "Argument is not a number.");
                    }
                    else
                    {
                        num = MathHelper.Clamp(num, 1, 14) - 1;
                        
                        SetColor(defaultColors[num]);
                        MyAPIGateway.Utilities.ShowMessage(MOD_NAME, "Color set to " + ColorToString(defaultColors[num]));
                    }
                    
                    return;
                }
                else if(msg.StartsWith("rgb") || msg.StartsWith("hsv"))
                {
                    bool hsv = msg.StartsWith("hsv");
                    msg = msg.Substring("rgb".Length).Trim();
                    
                    string[] split = msg.Split(' ');
                    
                    if(split.Length != 3)
                    {
                        MyAPIGateway.Utilities.ShowMessage(MOD_NAME, "Need to specify 3 numbers from 0 to 255 to create a RGB color.");
                    }
                    else
                    {
                        int[] values = new int[3];
                        
                        for(int i = 0; i < 3; i++)
                        {
                            if(!int.TryParse(split[i], out values[i]))
                            {
                                MyAPIGateway.Utilities.ShowMessage(MOD_NAME, "Color argument "+(i+1)+" is not a valid number!");
                                return;
                            }
                        }
                        
                        if(hsv)
                        {
                            SetColor(new Vector3(MathHelper.Clamp(values[0], 0, 360) / 360.0f, MathHelper.Clamp(values[1], -100, 100) / 100.0f, MathHelper.Clamp(values[2], -100, 100) / 100.0f));
                        }
                        else
                        {
                            SetColor(new Color((int)MathHelper.Clamp(values[0], 0, 255), (int)MathHelper.Clamp(values[1], 0, 255), (int)MathHelper.Clamp(values[2], 0, 255)).ColorToHSV());
                        }
                        
                        MyAPIGateway.Utilities.ShowMessage(MOD_NAME, "Color set to " + ColorToString(color));
                    }
                    
                    return;
                }
                else if(msg.Equals("cancel"))
                {
                    pickColor = false;
                    
                    MyAPIGateway.Utilities.ShowMessage(MOD_NAME, "Cancelled the picking color action.");
                    return;
                }
                
                MyAPIGateway.Utilities.ShowMessage(MOD_NAME, "Available commands:");
                MyAPIGateway.Utilities.ShowMessage("/pg pick ", "pick a color from an existing block");
                MyAPIGateway.Utilities.ShowMessage("/pg cancel ", "cancel the pick color action");
                MyAPIGateway.Utilities.ShowMessage("/pg default <1~14> ", "set the color ");
                MyAPIGateway.Utilities.ShowMessage("/pg rgb <0~255> <0~255> <0~255> ", "set the color using RGB format");
                MyAPIGateway.Utilities.ShowMessage("/pg hsv <0-360> <-100~100> <-100~100>", "set the color using HSV format");
            }
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        /*
        public class PaintStatus
        {
            public float progress = 0;
            public long started = 0;
            
            public PaintStatus()
            {
                started = DateTime.UtcNow.Ticks;
            }
        }
        
        Dictionary<string, PaintStatus> paintProgress = new Dictionary<string, PaintStatus>();
        
        public string BlockToKey(IMySlimBlock block)
        {
            return block.CubeGrid.EntityId+":"+block.Position.ToString();
        }
        
        /*
        // TODO REMOVE THIS CLUTTER ! xD
        public bool __HoldingTool(bool trigger)
        {
            try
            {
                /*
                var colorList = MyAPIGateway.Session.GetCheckpoint("null").CharacterToolbar.ColorMaskHSVList;
                var color = colorList[0];
         */
        
        /*
                var test = Sandbox.Game.Entities.MyCubeBuilder.AllPlayersColors;
                //var id =  new MyObjectBuilder_Checkpoint.PlayerId(MyAPIGateway.Session.Player.SteamUserId);
                
                var id = new Sandbox.Game.World.MyPlayer.PlayerId(MyAPIGateway.Session.Player.SteamUserId);
                
                MyAPIGateway.Utilities.ShowNotification("test="+test[id][0], 16, MyFontEnum.Green);
         */
        
        //MyAPIGateway.Utilities.ShowNotification("color="+color, 16, MyFontEnum.Green);
        
        /*
                var colors = MyAPIGateway.Session.GetCheckpoint("null").AllPlayersColors.Dictionary;
                if(colors != null)
                {
                    Log.Info("colors ok");
                    
                    var id =  new MyObjectBuilder_Checkpoint.PlayerId(MyAPIGateway.Session.Player.SteamUserId);
                    var colorList = colors[id];
                    
                    if(colorList != null)
                    {
                        //Log.Info("color list ok");
                        
                        color = colorList[0];
                        
                        MyAPIGateway.Utilities.ShowNotification("color="+color, 16, MyFontEnum.Blue);
                    }
                }
         */
        
        /*
                if(toolStatus == null)
                {
                    toolStatus = MyAPIGateway.Utilities.CreateNotification("", 300, MyFontEnum.White);
                    toolStatus.Hide();
                }
                
                var player = MyAPIGateway.Session.Player.Controller.ControlledEntity.Entity;
                var grid = MyAPIGateway.CubeBuilder.FindClosestGrid();
                
                if(grid == null)
                {
                    if(trigger)
                    {
                        SetToolStatus("No ship target for painting.\nPress your LIGHTS key to stop painting.", MyFontEnum.Red);
                    }
                    else if(pickColor)
                    {
                        SetToolStatus("Aim at a block to pick its color...\nor type /pg cancel to cancel the process.", MyFontEnum.Red);
                    }
                }
                else
                {
                    var view = MyAPIGateway.Session.ControlledObject.GetHeadMatrix(true, true);
                    var target = player.WorldAABB.Center + (view.Forward * grid.GridSize) + (view.Up * 0.6);
                    var pos = grid.WorldToGridInteger(target);
                    var block = grid.GetCubeBlock(pos);
                    string blockName = null;
                    
                    if(block != null)
                    {
                        if(block.FatBlock == null)
                        {
                            blockName = block.ToString();
                        }
                        else
                        {
                            blockName = block.FatBlock.DefinitionDisplayNameText;
                        }
                        
                        if(pickColor)
                        {
                            pickColor = false;
                            SetColor(block.GetColorMask());
                            MyAPIGateway.Utilities.ShowMessage(MOD_NAME, "Picked " + blockName + "'s color with " + String.Format("Hue: {0}; Saturation: {1}; Value: {2}", color.X, color.Y, color.Z));
                            return false;
                        }
                        
                        if(block.HasDeformation || block.CurrentDamage > 0 || (block.FatBlock != null && !block.FatBlock.IsFunctional))
                        {
                            SetToolStatus("Paint target: " + blockName + "\n" + (block.HasDeformation || block.CurrentDamage > 0 ? "Block is damaged or deformed and can't be painted!" : "Block is not fully built and can't be painted!"), MyFontEnum.Red);
                            return false;
                        }
                        
                        if(!trigger)
                        {
                            SetToolStatus("Paint target: " + blockName + "\nPress your LIGHTS key to start painting.", MyFontEnum.DarkBlue);
                        }
                    }
                    else
                    {
                        if(pickColor)
                        {
                            SetToolStatus("Aim at a block to pick its color...\nor type /pg cancel to cancel the process.", MyFontEnum.Red);
                        }
                        else if(trigger)
                        {
                            SetToolStatus("No block target for painting.\nPress your LIGHTS key to stop painting.", MyFontEnum.Red);
                        }
                    }
                    
                    if(trigger && block != null)
                    {
                        var blockColor = block.GetColorMask();
                        //RoundVector(ref blockColor, 2);
                        //RoundVector(ref color, 2);
                        
                        Vector3 blockSize;
                        block.ComputeScaledHalfExtents(out blockSize);
                        blockSize = ((blockSize * 2) / block.CubeGrid.GridSize);
                        
                        if(blockColor == color)
                        {
                            SetToolStatus(blockName + " is painted.\nPress your LIGHTS key to stop painting.", MyFontEnum.Green);
                            return false;
                        }
                        
                        /*
                        byte paintSpeed = 10; // (byte)((1 / Math.Max(blockSize.Volume * 0.33, 1)) * 10);
                        
                        var blockRGB = blockColor.HSVtoColor();
                        var colorRGB = color.HSVtoColor();
                        
                        if(blockRGB == colorRGB)
                        {
                            toolStatus.Show();
                            toolStatus.Text = blockName + " is painted.\nPress your LIGHTS key to stop painting.";
                            toolStatus.Font = MyFontEnum.Green;
                            return;
                        }
                        
                        var grayRGB = GRAY.HSVtoColor();
                        string key = BlockToKey(block);
                        PaintStatus paintStatus;
                        
                        if(paintProgress.TryGetValue(key, out paintStatus))
                        {
                            // continue painting
                            toolStatus.Text = "???% painting " + blockName + "...\nPress your LIGHTS key to stop painting.";
                            
                            paintStatus.started += (TimeSpan.TicksPerSecond * 2);
                            
                            if(blockRGB.R > colorRGB.R)
                                blockRGB.R = (byte)Math.Max(blockRGB.R - paintSpeed, colorRGB.R);
                            else
                                blockRGB.R = (byte)Math.Min(blockRGB.R + paintSpeed, colorRGB.R);
                            
                            if(blockRGB.G > colorRGB.G)
                                blockRGB.G = (byte)Math.Max(blockRGB.G - paintSpeed, colorRGB.G);
                            else
                                blockRGB.G = (byte)Math.Min(blockRGB.G + paintSpeed, colorRGB.G);
                            
                            if(blockRGB.B > colorRGB.B)
                                blockRGB.B = (byte)Math.Max(blockRGB.B - paintSpeed, colorRGB.B);
                            else
                                blockRGB.B = (byte)Math.Min(blockRGB.B + paintSpeed, colorRGB.B);
                            
                            if(blockRGB.A > colorRGB.A)
                                blockRGB.A = (byte)Math.Max(blockRGB.B - paintSpeed, colorRGB.A);
                            else
                                blockRGB.A = (byte)Math.Min(blockRGB.B + paintSpeed, colorRGB.A);
                            
                            if(blockRGB == colorRGB)
                            {
                                MyAPIGateway.Utilities.ShowMessage("DEBUG", "finished painting = " + blockRGB.ToString()); // TODO REMOVE
                                paintProgress.Remove(key);
                            }
                        }
                        else
                        {
                            // remove paint
                            toolStatus.Text = "???% removing paint from " + blockName + "...\nPress your LIGHTS key to stop painting.";
                            
                            if(blockRGB == grayRGB)
                            {
                                MyAPIGateway.Utilities.ShowMessage("DEBUG", "finished removing paint = " + blockRGB.ToString()); // TODO REMOVE
                                paintProgress.Add(key, new PaintStatus());
                                return;
                            }
                            
                            if(blockRGB.R > grayRGB.R)
                                blockRGB.R = (byte)Math.Max(blockRGB.R - paintSpeed, grayRGB.R);
                            else
                                blockRGB.R = (byte)Math.Min(blockRGB.R + paintSpeed, grayRGB.R);
                            
                            if(blockRGB.G > grayRGB.G)
                                blockRGB.G = (byte)Math.Max(blockRGB.G - paintSpeed, grayRGB.G);
                            else
                                blockRGB.G = (byte)Math.Min(blockRGB.G + paintSpeed, grayRGB.G);
                            
                            if(blockRGB.B > grayRGB.B)
                                blockRGB.B = (byte)Math.Max(blockRGB.B - paintSpeed, grayRGB.B);
                            else
                                blockRGB.B = (byte)Math.Min(blockRGB.B + paintSpeed, grayRGB.B);
                            
                            if(blockRGB.A > grayRGB.A)
                                blockRGB.A = (byte)Math.Max(blockRGB.B - paintSpeed, grayRGB.A);
                            else
                                blockRGB.A = (byte)Math.Min(blockRGB.B + paintSpeed, grayRGB.A);
                        }
                        
                        blockColor = blockRGB.ColorToHSV();
         */
        /*
                        float paintSpeed = (float)(1 / Math.Max(blockSize.Volume * 0.33, 1));
                        
                        if(blockColor.X == color.X)
                        {
                            paintSpeed *= PAINT_SPEED;
                            paintSpeed *= MyAPIGateway.Session.WelderSpeedMultiplier;
                            
                            float diff = (Math.Abs(blockColor.Y - color.Y) + Math.Abs(blockColor.Z - color.Z)) / 4;
                            float percent = 100 - (float)Math.Round(diff * 100, 0);
                            
                            SetToolStatus(percent + "% painting " + blockName + "...\nPress your LIGHTS key to stop painting.", MyFontEnum.Blue);
                            
                            if(blockColor.Y > color.Y)
                                blockColor.Y = Math.Max(blockColor.Y - paintSpeed, color.Y);
                            else
                                blockColor.Y = Math.Min(blockColor.Y + paintSpeed, color.Y);
                            
                            if(blockColor.Z > color.Z)
                                blockColor.Z = Math.Max(blockColor.Z - paintSpeed, color.Z);
                            else
                                blockColor.Z = Math.Min(blockColor.Z + paintSpeed, color.Z);
                        }
                        else
                        {
                            paintSpeed *= DEPAINT_SPEED;
                            paintSpeed *= MyAPIGateway.Session.GrinderSpeedMultiplier;
                            
                            float diff = (Math.Abs(blockColor.Y - DEFAULT_COLOR.Y) + Math.Abs(blockColor.Z - DEFAULT_COLOR.Z)) / 4;
                            float percent = 100 - (float)Math.Round(diff * 100, 0);
                            SetToolStatus(percent + "% removing paint from " + blockName + "...\nPress your LIGHTS key to stop painting.", MyFontEnum.Blue);
                            
                            blockColor.Y = Math.Max(blockColor.Y - paintSpeed, DEFAULT_COLOR.Y);
                            
                            if(blockColor.Z > 0)
                                blockColor.Z = Math.Max(blockColor.Z - paintSpeed, DEFAULT_COLOR.Z);
                            else
                                blockColor.Z = Math.Min(blockColor.Z + paintSpeed, DEFAULT_COLOR.Z);
                            
                            if(blockColor.Y == DEFAULT_COLOR.Y && blockColor.Z == DEFAULT_COLOR.Z)
                            {
                                blockColor.X = color.X;
                            }
                        }
                        
                        /*
                        ushort percent;
                        float paintSpeed = (float)(1 / Math.Round(blockSize.Volume * 0.8, 0));
                        
                        //MyAPIGateway.Utilities.ShowNotification("blockColor="+blockColor+"; color="+color, 160, MyFontEnum.White); // TODO REMOVE
                        
                        // TODO close enough HUE without depainting ?
                        
                        if(blockColor.X == color.X) // && blockColor.Z == color.Z) // hue is the same, proceed to painting by adding to saturation and value
                        {
                            paintSpeed *= PAINT_SPEED;
                            percent = (ushort)Math.Round(((1 + blockColor.Y) / (1 + color.Y)) * 100, 0);
                            toolStatus.Text = percent + "% painting " + blockName + "...\nPress your LIGHTS key to stop painting.";
                            
                            blockColor.Y = Math.Min(blockColor.Y + paintSpeed, color.Y);
                            
                            if(blockColor.Z > color.Z)
                                blockColor.Z = Math.Max(blockColor.Z - paintSpeed, color.Z);
                            else
                                blockColor.Z = Math.Min(blockColor.Z + paintSpeed, color.Z);
                            
                            MyAPIGateway.Utilities.ShowMessage("DEBUG", "colorizing... y="+blockColor.Y+"; z="+blockColor.Z); // TODO REMOVE
                        }
                        else // hue is not the same, decolorize by removing from saturation and value
                        {
                            paintSpeed *= DEPAINT_SPEED;
                            percent = (ushort)Math.Round((1 - ((1 + blockColor.Y) / 2)) * 100, 0);
                            toolStatus.Text = percent + "% removing paint on " + blockName + "...\nPress your LIGHTS key to stop.";
                            
                            MyAPIGateway.Utilities.ShowMessage("DEBUG", "decolorizing... y="+blockColor.Y+"; z="+blockColor.Z); // TODO REMOVE
                            
                            blockColor.Y = Math.Max(blockColor.Y - paintSpeed, -1);
                            
                            if(blockColor.Z > 0)
                                blockColor.Z = Math.Max(blockColor.Z - paintSpeed, 0);
                            else
                                blockColor.Z = Math.Min(blockColor.Z + paintSpeed, 0);
                            
                            if(blockColor.Y == -1 && blockColor.Z == 0)
                            {
                                MyAPIGateway.Utilities.ShowMessage("DEBUG", "reached full decoloration; y="+blockColor.Y+"; z="+blockColor.Z); // TODO REMOVE
                                
                                blockColor.X = color.X;
                            }
                        }
         */
        
        /*
                        if(blockColor.X == color.X && blockColor.Z == color.Z)
                        {
                            percent = (ushort)Math.Round(((1 + blockColor.Y) / (1 + color.Y)) * 100, 0);
                            toolStatus.Text = percent + "% painting " + blockName + "...\nPress your LIGHTS key to stop painting.";
                            
                            blockColor.Y = Math.Min(blockColor.Y + PAINT_SPEED, color.Y);
                            
                            MyAPIGateway.Utilities.ShowMessage("DEBUG", "colorizing..."); // TODO REMOVE
                        }
                        else
                        {
                            percent = (ushort)Math.Round((1 - ((1 + blockColor.Y) / 2)) * 100, 0);
                            toolStatus.Text = percent + "% removing paint on " + blockName + "...\nPress your LIGHTS key to stop.";
                            
                            MyAPIGateway.Utilities.ShowMessage("DEBUG", "decolorizing..."); // TODO REMOVE
                            
                            blockColor.Y = Math.Max(blockColor.Y - DEPAINT_SPEED, -1);
                            
                            if(blockColor.Y == -1)
                            {
                                blockColor.X = color.X;
                                blockColor.Z = color.Z;
                                
                                MyAPIGateway.Utilities.ShowMessage("DEBUG", "reached full decoloration"); // TODO REMOVE
                            }
                        }
         */
        /*
                        grid.ColorBlocks(pos, pos, blockColor);
                        return true;
                        
                        /*
                        bool coloring = true;
                        
                        if(blockColor != GRAY)
                        {
                            coloring = false;
                            blockColor.X = GRAY.X;
                            blockColor.Z = GRAY.Z;
                        }
                        else if(blockColor.X == GRAY.X && blockColor.Z == GRAY.Z && blockColor.Y > -1)
                        {
                            coloring = false;
                            blockColor.Y = Math.Max(blockColor.Y - DEPAINT_SPEED, -1);
                        }
                        else
                        {
                            if(blockColor.X != color.X || blockColor.Z != color.Z)
                            {
                                blockColor = color;
                                blockColor.Y = -1;
                            }
                            else
                            {
                                blockColor.Y = Math.Min(blockColor.Y + PAINT_SPEED, color.Y);
                            }
                        }
                        
                        grid.ColorBlocks(pos, pos, blockColor);
                        
                        ushort percent = (ushort)Math.Round(((1 + blockColor.Y) / (1 + color.Y)) * 100, 0);
                        
                        toolStatus.Show();
                        if(coloring)
                            toolStatus.Text = percent + "% painting " + blockName + "...\nPress your LIGHTS key to stop painting.";
                        else
                            toolStatus.Text = percent + "% removing paint on " + blockName + "...\nPress your LIGHTS key to stop.";
                        toolStatus.Font = MyFontEnum.Blue;
         */
        /*
                    }
                }
                
                /*
                var view = MyAPIGateway.Session.ControlledObject.GetHeadMatrix(true, true);
                var target = player.WorldAABB.Center + (view.Forward * 2) + (view.Up * 0.75);
                
                var box = new BoundingBoxD(target - 0.1, target + 0.1);
                var ents = MyAPIGateway.Entities.GetEntitiesInAABB(ref box);
                //List<Vector3I> hit = new List<Vector3I>();
                
                foreach(var ent in ents)
                {
                    if(ent is IMyCubeGrid && ent.Physics != null && !ent.Physics.IsPhantom)
                    {
                        var grid = ent as IMyCubeGrid;
                        
                        var pos = grid.WorldToGridInteger(target);
                        var block = grid.GetCubeBlock(pos);
                        MyAPIGateway.Utilities.ShowNotification("pos="+pos+"; block="+(block == null ? "null" : block.ToString()), 16, MyFontEnum.Red);
                        
                        if(trigger && block != null)
                        {
                            MyAPIGateway.Utilities.ShowNotification("Color at " + pos, 1000, MyFontEnum.Green);
                            grid.ColorBlocks(pos, pos, color);
                        }
                        
                        break;
                        
                        /*
                        hit.Clear();
                        grid.RayCastCells(view.Translation, target + (view.Forward * 2), hit, null, true);
                        
                        if(hit.Count > 0)
                        {
                            MyAPIGateway.Utilities.ShowNotification("Hit count="+hit.Count+"; list="+String.Join(",", hit), 16, MyFontEnum.Red);
                            block = grid.GetCubeBlock(hit[0]);
                            
                            if(trigger)
                            {
                                MyAPIGateway.Utilities.ShowNotification("Color at " + hit[0], 1000, MyFontEnum.Green);
                                grid.ColorBlocks(hit[0], hit[0], new Vector3(0,0,0));
                                
                                if(block == null)
                                {
                                    //MyAPIGateway.Utilities.ShowNotification("No block found!", 1000, MyFontEnum.Red);
                                }
                                else
                                {
                                    MyAPIGateway.Utilities.ShowNotification(block.ToString() + " colored!", 1000, MyFontEnum.Green);
                                }
                            }
                            
                            break;
                        }
                    }
                }
         */
        
        
        
        
        /*
            if(!MyAPIGateway.Entities.IsRaycastBlocked(view.Translation, target))
                return;
            
            /*
            MyAPIGateway.Entities.GetEntities(null,
                delegate( IMyEntity entity )
                {
                    var ObjectPos = GetPosition(entity);
                    LineD LineToTarget = new LineD(position, ObjectPos);
                    RayD Intersector = new RayD(LineToTarget.To, -LineToTarget.Direction); //ray from target to radar ship
                    if (LineToTarget.Length < range)
                    {
                        bool IsBlocked = false;
                        double TargetRange = 0.0;
                        double? RangeFromTarget = null;
                        if ((entity is IMyCubeGrid) || (entity is IMyVoxelMap)) TargetRange = entity.WorldVolume.Radius * WorldVolumeMultiplier;
                        else { }
                        if ((ObjectPos - ShipPos).Length() > (ShipRange + TargetRange))
                        {
                            RangeFromTarget = Intersector.Intersects(GetShipSphere()); //get point on overall sphere of radar ship (=outside all blocks)
                            if (RangeFromTarget.HasValue)
                            {
                                LineToTarget.From = Intersector.Position + Intersector.Direction * RangeFromTarget.Value;
                            }
                            LineToTarget.To -= LineToTarget.Direction * TargetRange;
                            IsBlocked = MyAPIGateway.Entities.IsRaycastBlocked(LineToTarget.From, LineToTarget.To);
                        }
                        else
                        {
                        }
                        if (IsBlocked) { } else foreach (var selector in selectors) selector.Examine(entity);
                    }
                    return false;
                }
               );
         */
        
        /*
            var ray = new RayD(view.Translation, view.Forward);
            IMySlimBlock block = null;
            List<Vector3I> hit = new List<Vector3I>();
            
            ents.Clear();
            MyAPIGateway.Entities.GetEntities(ents,
                                              delegate(IMyEntity ent)
                                              {
                                                  if(block != null)
                                                      return false;
                                                  
                                                  if(ent is IMyCubeGrid)
                                                  {
                                                      var cast = ray.Intersects(ent.WorldVolume);
                                                      
                                                      if(cast.HasValue)
                                                      {
                                                          var grid = ent as IMyCubeGrid;
                                                          var hitBlock = grid.RayCastBlocks(view.Translation, target);
                                                          
                                                          if(hitBlock.HasValue)
                                                          {
                                                              block = grid.GetCubeBlock(hitBlock.Value);
                                                              return true;
                                                          }
                                                          
                                                          hit.Clear();
                                                          grid.RayCastCells(view.Translation, target, hit, null, false);
                                                          
                                                          if(hit.Count > 0)
                                                          {
                                                              MyAPIGateway.Utilities.ShowNotification("Hit count="+hit.Count+"; list="+String.Join(",", hit), 16, MyFontEnum.Green);
                                                              block = grid.GetCubeBlock(hit[0]);
                                                              return true;
                                                          }
                                                      }
                                                  }
                                                  
                                                  return false;
                                              });
            
            
            MyAPIGateway.Utilities.ShowNotification("block="+block, 16, MyFontEnum.Red);
            
            if(trigger)
            {
                if(block != null)
                {
                    block.CubeGrid.ColorBlocks(block.Position, block.Position, color);
                    MyAPIGateway.Utilities.ShowNotification("Painted!", 1000, MyFontEnum.Green);
                }
            }
         */
        /*
            }
            catch(Exception e)
            {
                Log.Error(e);
            }
            
            return false;
        }
         */
    }
}